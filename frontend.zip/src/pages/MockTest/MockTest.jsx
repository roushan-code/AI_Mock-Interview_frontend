import React, { useState, useEffect, useContext } from 'react';
import DashboardLayout from "../../components/layouts/DashboardLayout";
import {  LuClock } from 'react-icons/lu';
import { BsBookmark } from "react-icons/bs";
import {UserContext } from '../../context/useContext';

const MockTest = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [timeRemaining, setTimeRemaining] = useState(25 * 60); // 25 minutes in seconds

  const { metaData, setMetaData } = useContext(UserContext);
  useEffect(() => {
  console.log(metaData);
}, [metaData]);
  
 
  
  // const [updatedData, setUpdatedData] = useState(mockData)
  // Timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format time to MM:SS
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNextQuestion = () => {
    if (currentQuestion < metaData.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedAnswer('');
    }
  };

  const handleOptionSelect = (optionId) => {
    setSelectedAnswer(optionId);
    setMetaData(prevMetaData => ({
    ...prevMetaData,
    questions: prevMetaData.questions.map((question, index) => 
      index === currentQuestion 
        ? {
                     ...question,
                     options: question.options.map(option =>
                         option.id === optionId ? { ...option, isSelected: true } : { ...option, isSelected: false }
                     )
                 }
        : question
    )
  }));


  };
  // console.log(metaData)
  const currentQuestionData = metaData.questions[currentQuestion];

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-transparent p-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
          
          {/* Left Panel - Course Info & Questions List */}
          <div className="bg-[#1e1e3f]/80 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
            {/* Course Header */}
            <div className="mb-6">
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
                Course: <span className="text-purple-400">{metaData.course}</span>
              </h1>
              <p className="text-gray-300 text-sm md:text-base mb-4">
                <span className="text-purple-300">Topics:</span> {metaData.topics}
              </p>
              
              {/* Stats Pills */}
              <div className="flex flex-wrap gap-3">
                <div className="bg-purple-900/50 border border-purple-500/50 rounded-full px-4 py-2">
                  <span className="text-purple-300 text-sm font-medium">
                    Total marks: {metaData.totalMarks}
                  </span>
                </div>
                <div className="bg-purple-900/50 border border-purple-500/50 rounded-full px-4 py-2">
                  <span className="text-purple-300 text-sm font-medium">
                    {metaData.totalQuestions} Q&A
                  </span>
                </div>
                <div className="bg-purple-900/50 border border-purple-500/50 rounded-full px-4 py-2">
                  <span className="text-purple-300 text-sm font-medium">
                    Total Time: {metaData.totalTime}
                  </span>
                </div>
              </div>
            </div>

            {/* Questions List */}
            <div className="space-y-3">
              {metaData.questions.map((question, index) => (
                <div
                  key={question.id}
                  className={`flex items-center justify-between p-4 rounded-xl cursor-pointer transition-all duration-200 ${
                    currentQuestion === index
                      ? 'bg-purple-600/30 border border-purple-500'
                      : 'bg-gray-800/50 border border-gray-600/30 hover:bg-gray-700/50'
                  }`}
                  onClick={() => {setCurrentQuestion(index), setSelectedAnswer('')}}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-white font-medium">
                      {index + 1}.
                    </span>
                    <span className="text-gray-300 text-sm truncate">
                      {question.question.length > 50 
                        ? `${question.question.substring(0, 50)}...`
                        : question.question
                      }
                    </span>
                  </div>
                  <BsBookmark className="text-gray-400 flex-shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {/* Right Panel - Current Question */}
          <div className="bg-[#1e1e3f]/80 backdrop-blur-sm rounded-2xl p-6 border border-purple-500/20">
            {/* Timer Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <span className="text-purple-300 text-sm font-medium">Mock Interview Test</span>
              </div>
              <div className="flex items-center space-x-2 bg-red-900/50 border border-red-500/50 rounded-full px-4 py-2">
                <LuClock className="text-red-400" size={16} />
                <span className="text-red-400 font-mono font-bold">
                  {formatTime(timeRemaining)}
                </span>
              </div>
            </div>

            {/* Question */}
            <div className="mb-8">
              <h2 className="text-xl md:text-2xl font-semibold text-white leading-relaxed italic">
                {currentQuestionData.question}
              </h2>
            </div>

            {/* Options */}
            <div className="space-y-4 mb-8">
              {currentQuestionData.options.map((option) => (
                <button
                  key={option.id}
                  onClick={()=> handleOptionSelect(option.id)}
                  className={`w-full p-4 rounded-xl text-left transition-all duration-200 border ${
                    (selectedAnswer === option.id || option.isSelected)
                      ? 'bg-green-600/30 border-green-400 text-white'
                      : 'bg-gray-800/50 border-gray-600/30 text-gray-300 hover:bg-gray-700/50 hover:border-gray-500/50'
                  }`}
                >
                  <span className="font-medium mr-3">{option.id}.</span>
                  <span>{option.text}</span>
                </button>
              ))}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between">
              <button
                onClick={handlePreviousQuestion}
                disabled={currentQuestion === 0}
                className="px-6 py-3 bg-gray-700/50 border border-gray-600/50 rounded-xl text-white font-medium transition-all duration-200 hover:bg-gray-600/50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              
              <button
                onClick={handleNextQuestion}
                className="px-6 py-3 bg-purple-600 border border-purple-500 rounded-xl text-white font-medium transition-all duration-200 hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {(currentQuestion === metaData.questions.length - 1) ? "Submit" : "Next"}
              </button>
            </div>

            {/* Progress Indicator */}
            <div className="mt-6">
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Question {currentQuestion + 1} of {metaData.questions.length}</span>
                <span>{Math.round(((currentQuestion + 1) / metaData.questions.length) * 100)}% Complete</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / metaData.questions.length) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default MockTest;