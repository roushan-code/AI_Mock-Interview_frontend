import React, { createContext, useState, useContext, useEffect } from "react";
import axiosInstance from "../utils/axiosInstance";
import { API_PATHS } from "../utils/apiPaths";


const mockData = {
    course: "BCA",
    topics: "C, Math, python, Networking",
    totalMarks: 20,
    totalQuestions: 20,
    totalTime: "25 min",
    questions: [
        {
            id: 1,
            question: "Which programming language is primarily used in machine learning?",
            options: [
                { id: 'A', text: 'C++' },
                { id: 'B', text: 'Ruby' },
                { id: 'C', text: 'Python' },
                { id: 'D', text: 'Html' }
            ],
            correctAnswer: 'C'
        },
        {
            id: 2,
            question: "What is #include?",
            options: [
                { id: 'A', text: 'A preprocessor directive' },
                { id: 'B', text: 'A function' },
                { id: 'C', text: 'A variable' },
                { id: 'D', text: 'A comment' }
            ],
            correctAnswer: 'A'
        },
        {
            id: 3,
            question: "What is python?",
            options: [
                { id: 'A', text: 'A snake' },
                { id: 'B', text: 'A programming language' },
                { id: 'C', text: 'A database' },
                { id: 'D', text: 'An operating system' }
            ],
            correctAnswer: 'B'
        },
        {
            id: 4,
            question: "What is Computer Networking?",
            options: [
                { id: 'A', text: 'Connecting computers together' },
                { id: 'B', text: 'Installing software' },
                { id: 'C', text: 'Hardware repair' },
                { id: 'D', text: 'Data storage' }
            ],
            correctAnswer: 'A'
        }
    ]
};


export const UserContext = createContext();

const UserProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);


    const [metaData, setMetaData] = useState(mockData);

    useEffect(() => {
        if (user) return;

        const accessToken = localStorage.getItem("token");
        if (!accessToken) {
            setLoading(false);
            return;
        }


        const fetchUser = async () => {
            try {
                const response = await axiosInstance.get(API_PATHS.AUTH.GET_PROFILE);
                setUser(response.data);
            } catch (err) {
                console.error("Error fetching user data:", err);
                clearUser();
            } finally {
                setLoading(false);
            }
        };
        fetchUser();
    }, []);

    const updateUser = (userData) => {
        setUser(userData);
        localStorage.setItem("token", userData.token);
        setLoading(false);
    };

    const clearUser = () => {
        setUser(null);
        localStorage.removeItem("token");
    }

    // const updateData = (currentQuestion, optionId) => {
    //     let data = metaData;
    //     const updatedQuestions = data.questions.map((question, index) => {
    //         if (index === currentQuestion) {
    //             return {
    //                 ...question,
    //                 options: question.options.map(option =>
    //                     option.id === optionId ? { ...option, isSelected: true } : { ...option, isSelected: false }
    //                 )
    //             };
    //         }
    //         return question;
    //     });
    //     data.questions = updatedQuestions
    //     console.log(data)
    //     setMetaData(data)
    // }


    return (
        <UserContext.Provider value={{ user, loading, updateUser, clearUser, metaData, setMetaData }}>
            {children}
        </UserContext.Provider>
    );
}

export default UserProvider;